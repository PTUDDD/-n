package com.example.pikachu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

import object.CauHoi;

public class MainActivity2 extends AppCompatActivity {
    CauHoi cauHoi;

    int viTriCauHoi = 1;

    String cauTraLoi;

    TextView txvCauHoi,txvCauTL1,txvCauTL2,txvCauTL3,txvCauTL4,txvThuaGame;
    ArrayList<TextView> arrTxvCauTraLoi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        init();
        anhxa();
        setUp();
        setClick();
    }

    private void setClick() {
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkCauTraLoi(((TextView)view));
            }
        };
        for (TextView t:arrTxvCauTraLoi){
            t.setOnClickListener(listener);
        }
    }

    public void checkCauTraLoi(TextView txv) {
         cauTraLoi = txv.getText().toString();
        txv.setBackgroundResource(R.drawable.bg_cau_chon);

        new CountDownTimer(1000,100){

            @Override
            public void onTick(long l) {

            }

            @Override
            public void onFinish() {
                for (TextView t : arrTxvCauTraLoi){
                    String s = t.getText().toString();
                    if(s.equals(cauHoi.getDapAnDung())){
                        t.setBackgroundResource(R.drawable.bg_cau_dung);
                        break;
                    }
                }
                new CountDownTimer(1000, 100) {
                    @Override
                    public void onTick(long l) {

                    }

                    @Override
                    public void onFinish() {
                        if(cauTraLoi.equals(cauHoi.getDapAnDung())){
                            viTriCauHoi++;
                            if(viTriCauHoi>=15){
                                viTriCauHoi=15;
                            }
                            hienCauHoi();
                        }else{
                            txvThuaGame.setVisibility(View.VISIBLE);
                            txvThuaGame.setText("Bạn đã thua!! Cảm ơn bạn đã sử dụng ứng dụng");
                        }
                    }
                }.start();
            }
        }.start();


    }

    private void setUp() {
        txvThuaGame.setVisibility(View.GONE);

        setCauHoi();

        hienCauHoi();
    }

    private void anhxa() {
        txvCauHoi = findViewById(R.id.txvCauHoi);
        txvCauTL1 = findViewById(R.id.txvCauTL1);
        txvCauTL2 = findViewById(R.id.txvCauTL2);
        txvCauTL3 = findViewById(R.id.txvCauTL3);
        txvCauTL4 = findViewById(R.id.txvCauTL4);
        txvThuaGame = findViewById(R.id.txvThuaGame);

        arrTxvCauTraLoi.add(txvCauTL1);
        arrTxvCauTraLoi.add(txvCauTL2);
        arrTxvCauTraLoi.add(txvCauTL3);
        arrTxvCauTraLoi.add(txvCauTL4);
    }

    private void init() {
        cauHoi = new CauHoi();

        arrTxvCauTraLoi = new ArrayList<>();
    }

    public void setCauHoi() {
        cauHoi .setNoiDung("1+1=");
        cauHoi .setDapAnDung("2");
        ArrayList<String> arrDapAnSai = new ArrayList<>();
        arrDapAnSai.add("3");
        arrDapAnSai.add("4");
        arrDapAnSai.add("5");
        cauHoi .setArrDapAnSai(arrDapAnSai);
    }

    public void hienCauHoi() {
        txvCauHoi.setText(cauHoi.getNoiDung());
        ArrayList<String> arrCauTraLoi = new ArrayList<>(cauHoi.getArrDapAnSai());
        arrCauTraLoi.add(cauHoi.getDapAnDung());

        Random r = new Random();
        for(int i=0; i<5; i++){
            int vt1 = r.nextInt(arrCauTraLoi.size());
            int vt2 = r.nextInt(arrCauTraLoi.size());
            String a = arrCauTraLoi.get(vt1);
            arrCauTraLoi.set(vt1,arrCauTraLoi.get(vt2));
            arrCauTraLoi.set(vt2,a);
        }

        for (int i=0; i<arrTxvCauTraLoi.size();i++){
            arrTxvCauTraLoi.get(i).setBackgroundResource(R.drawable.bg_btn);
            arrTxvCauTraLoi.get(i).setText(arrCauTraLoi.get(i));
        }
    }
}